#ifndef _MAIN_H_
#define _MAIN_H_

#include "global.h"

int main(int ,char**);
void initialize (void);
bool callbackFunc(btManifoldPoint& ,const btCollisionObject* ,int ,int ,const btCollisionObject* ,int ,int);

#endif