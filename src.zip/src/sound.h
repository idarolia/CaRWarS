#include "global.h"

bool init();
bool loadMedia();
void close();
void initializeSound();
