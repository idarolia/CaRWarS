#include "global.h"

void computePos(float deltaMove);
void renderGame(void);
void initialize (void);
void changeSize(int w, int h);
void initializeGame (void);