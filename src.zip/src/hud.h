#include "global.h"

void renderHUD(void);