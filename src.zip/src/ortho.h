#include "global.h"

int loadTex(std::string);
void orthoSet(void);
void orthoReset(void);