#include "global.h"

void mainMenuCall(void);
void renderGameMenu(void);
void renderPauseMenu(void);
void renderWorldMenu(void);
void renderSettingsMenu(void);
void renderMenu(void);